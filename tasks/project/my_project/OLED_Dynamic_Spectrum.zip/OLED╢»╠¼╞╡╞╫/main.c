#include "STC12c5a60s2.H"
#include <math.h>
#include "SRC\oled.h"
#define uchar unsigned char
#define uint unsigned int
sbit sb0=P3^6;		//���尴ťλ��

idata uchar fft_shuzu[2][32];

struct compx       //���帴���ṹ��
{
        float real;
        float imag;
};
xdata struct compx s[64];                                                 //FFT���ݻ������XDATA�ռ�
struct compx EE(struct compx a1,struct compx b2)         //�����˷�
{
        struct compx b3;
        b3.real=a1.real*b2.real-a1.imag*b2.imag;
        b3.imag=a1.real*b2.imag+a1.imag*b2.real;
        return(b3);
} 

/*FFT����*/
void FFT(struct compx xin[],int N)                                   
{
        int f,m,nv2,nm1,i,k,j=1,l;
        struct compx v,w,t;
        nv2=N/2;
        f=N;
        for(m=1;(f=f/2)!=1;m++){;}
        nm1=N-1;
        for(i=0;i<nm1;i++)                                           //�������
        {
                if(i<j)
                {
                        t=xin[j];
                        xin[j]=xin[i];
                        xin[i]=t;
                }
                k=nv2;                                                       //kΪ��������Ӧλ�õ�Ȩֵ
                while(k<j)
                {
                        j=j-k;
                        k=k/2;
                }
                j=j+k;
        } 
        {
                int le,lei,ip;
                  float pi;
                  for(l=1;l<=m;l++)
                   {
                le=pow(2,l);                                                 //�˷�
                    lei=le/2;
                    pi=3.14159265;
                    v.real=1.0;
                v.imag=0.0;  
                   w.real=cos(pi/lei);                                           //��ת����
                    w.imag=-sin(pi/lei);
                    
                for(j=1;j<=lei;j++)                                           //���Ƶ�������ļ���
                     {
                        for(i=j-1;i<N;i=i+le)                                         //����ÿ����������Ĵ���
                              {
                                    ip=i+lei;
                                       t=EE(xin[ ip ],v);
                                       xin[ ip ].real=xin[ i ].real-t.real;   //���μ���
                                       xin[ ip ].imag=xin[ i ].imag-t.imag;
                                       xin[ i ].real=xin[ i ].real+t.real;
                                       xin[ i ].imag=xin[ i ].imag+t.imag;
                              }
                              v=EE(v,w);   
                      }     
                   }
          }
}

void showbar0()//��ʱ��ñ����
{                                
    unsigned char i,j,x,p,high,tigh,temp,itemp;
        xdata unsigned char dis_rdata[16]; 
        for(i=0;i<16;i++)          //��ȡFFTת������
        {
                float t0=0;
                t0=sqrt(pow((s[i].real+s[i+1].real),2)+pow((s[i].imag+s[i+1].imag),2))/2;
                dis_rdata[i]=(unsigned char)t0;
        }
        OLED_Display_On();
        for(i=0;i<16;i++)//16������������
        {
                itemp=high=0;
                itemp=high=dis_rdata[i];//�Դ���������ֵ
                high=high/5;
                for(x=0;x<8;x++)//��յ�ǰ�������ռ�
                {
                        OLED_Set_Pos(i*8,7-x); 
                        temp=0x00;
                        for(j=0;j<8;j++)
                        {
                                OLED_WR_Byte(temp,1);
                        }
                }
                
                if(high>64)high=64;//���ֵ����
                if(fft_shuzu[0][i]<=high)//��⵱ǰ��С
                {
                        fft_shuzu[0][i]=high;//���ڸ�ֵ��ǰƵ��ñΪ��ֵ
                        fft_shuzu[1][i]=10;//�������õ�ǰ��ʱ
                }
                fft_shuzu[1][i]--;//��ǰ��ʱ�Լ�
                if(fft_shuzu[1][i]==0)//�����ǰ��ʱΪ0
                {
                        fft_shuzu[0][i]=high;//ǿ�ȵ��ڵ�ǰ��С
                }
                
                p=high/8;                //ɨ��ͼ������
                tigh=high%8;
                for(x=0;x<p;x++)//������Ԫ����
                {
                        OLED_Set_Pos(i*8,7-x); 
                        temp=0xff;
                        for(j=0;j<7;j++)
                        {
                                OLED_WR_Byte(temp,1);
                        }
                }
                
                p=fft_shuzu[0][i]/8;//������ʱñ����λ�ú���
                tigh=fft_shuzu[0][i]%8;
                if((itemp/8)==p)//���������λ���غ�
                {
                        OLED_Set_Pos(i*8,7-p);//��������λ��
                        temp=0x80>>tigh;//������ʱñ
                        temp=temp|~0xff>>(high%8);//�ϲ���ǰλ��
                        for(j=0;j<7;j++)//������Ļ
                        {
                                OLED_WR_Byte(temp,1);
                        }
                }
                else//������غ�
                {
                        OLED_Set_Pos(i*8,7-p);//��������λ��
                        temp=0x80>>tigh;//������ʱñ
                        for(j=0;j<7;j++)//������Ļ
                        {
                                OLED_WR_Byte(temp,1);
                        }
                        
                        OLED_Set_Pos(i*8,7-(high/8));//�����������Ԫ
                        temp=~0xff>>(itemp%8);//����������
                        for(j=0;j<7;j++)//����
                        {
                                OLED_WR_Byte(temp,1);
                        }
                }
        }
}

void showbar1()//����������
{                                
    unsigned char i,j,x,p,high,tigh,temp;
        xdata unsigned char dis_rdata[16]; 
        for(i=0;i<16;i++)          //��ȡFFTת������
        {
                float t0=0;
                t0=sqrt(pow((s[i].real+s[i+1].real),2)+pow((s[i].imag+s[i+1].imag),2))/2;
                dis_rdata[i]=(unsigned char)t0;
        }
        OLED_Display_On();
        for(i=0;i<16;i++)
        {
                high=0;
                high=dis_rdata[i];
                high=high/5;
                for(x=0;x<8;x++)
                {
                        OLED_Set_Pos(i*8,7-x); 
                        temp=0x00;
                        for(j=0;j<8;j++)
                        {
                                OLED_WR_Byte(temp,1);
                        }
                }
                if(high>64)high=64;
                if(high==0)high=1;
                p=high/8;
                tigh=high%8;
                for(x=0;x<p;x++)
                {
                        OLED_Set_Pos(i*8,7-x); 
                        temp=0xff;
                        for(j=0;j<7;j++)
                        {
                                OLED_WR_Byte(temp,1);
                        }
                }
                OLED_Set_Pos(i*8,7-(high/8));
                temp=~0xff>>(high%8);
                for(j=0;j<7;j++)
                {
                        OLED_WR_Byte(temp,1);
                }
        }
}

void showbar2()
{                                
    unsigned char i,j,x,p,high,tigh,temp,itemp;
        xdata unsigned char dis_rdata[16]; 
        for(i=0;i<16;i++)          //��ȡFFTת������
        {
                float t0=0;
                t0=sqrt(pow((s[i  ].real+s[i+1].real),2)+pow((s[i  ].imag+s[i+1].imag),2))/2;
                dis_rdata[i]=(unsigned char)t0;
        }
        OLED_Display_On();
        for(i=0;i<16;i++)
        {
                itemp=high=0;
                itemp=high=dis_rdata[i];
                high=high/5;
                for(x=0;x<8;x++)
                {
                        OLED_Set_Pos(i*8,7-x); 
                        temp=0x00;
                        for(j=0;j<8;j++)
                        {
                                OLED_WR_Byte(temp,1);
                        }
                }
                if(high>64)high=64;
                p=high/8;
                tigh=high%8;
                if(p==0)
                {
                        p=1;
                        temp=0x80;
                }
                else temp=0x88;
                for(x=0;x<p;x++)
                {
                        OLED_Set_Pos(i*8,7-x); 
                        for(j=0;j<7;j++)
                        {
                                OLED_WR_Byte(temp,1);
                        }
                }
        }
}

void showbar3()
{                                
    unsigned char i,j,x,p,high,tigh,temp,itemp;
        xdata unsigned char dis_rdata[16]; 
        for(i=0;i<16;i++)          //��ȡFFTת������
        {
                float t0=0;
                t0=sqrt(pow((s[i].real+s[i+1].real),2)+pow((s[i].imag+s[i+1].imag),2))/2;
                dis_rdata[i]=(unsigned char)t0;
        }
        OLED_Display_On();
        for(i=0;i<16;i++)
        {
                itemp=high=0;
                itemp=high=dis_rdata[i];
                high=high/5;
                for(x=0;x<8;x++)
                {
                        OLED_Set_Pos(i*8,7-x); 
                        temp=0xFF;
                        for(j=0;j<8;j++)
                        {
                                OLED_WR_Byte(temp,1);
                        }
                }
                
                if(high>64)high=64;
                if(fft_shuzu[0][i]<=high)
                {
                        fft_shuzu[0][i]=high;
                        fft_shuzu[1][i]=10;
                }
                fft_shuzu[1][i]--;
                if(fft_shuzu[1][i]==0)
                {
                        fft_shuzu[0][i]=high;
                }
                
                p=high/8;
                tigh=high%8;
                for(x=0;x<p;x++)
                {
                        OLED_Set_Pos(i*8,7-x); 
                        temp=0x00;
                        for(j=0;j<7;j++)
                        {
                                OLED_WR_Byte(temp,1);
                        }
                }
                
                p=fft_shuzu[0][i]/8;
                tigh=fft_shuzu[0][i]%8;
                if((itemp/8)==p)
                {
                        OLED_Set_Pos(i*8,7-p);
                        temp=~0x80>>tigh;
                        temp=temp|0xff>>(high%8);
                        for(j=0;j<7;j++)
                        {
                                OLED_WR_Byte(temp,1);
                        }
                }
                else
                {
                        OLED_Set_Pos(i*8,7-p);
                        temp=~0x80>>tigh;
                        for(j=0;j<7;j++)
                        {
                                OLED_WR_Byte(temp,1);
                        }
                        
                        OLED_Set_Pos(i*8,7-(high/8));
                        temp=0xff>>(itemp%8);
                        for(j=0;j<7;j++)
                        {
                                OLED_WR_Byte(temp,1);
                        }
                }
        }
}

void showbar4()
{                                
    unsigned char i,j,x,p,high,tigh,temp;
        xdata unsigned char dis_rdata[16]; 
        for(i=0;i<16;i++)          //��ȡFFTת������
        {
                float t0=0;
                t0=sqrt(pow((s[i  ].real+s[i+1].real),2)+pow((s[i  ].imag+s[i+1].imag),2))/2;
                dis_rdata[i]=(unsigned char)t0;
        }
        OLED_Display_On();
        for(i=0;i<16;i++)
        {
                high=0;
                high=dis_rdata[i];
                high=high/5;
                for(x=0;x<8;x++)
                {
                        OLED_Set_Pos(i*8,7-x); 
                        temp=0xff;
                        for(j=0;j<8;j++)
                        {
                                OLED_WR_Byte(temp,1);
                        }
                }
                if(high>64)high=64;
                if(high==0)high=1;
                p=high/8;
                tigh=high%8;
                for(x=0;x<p;x++)
                {
                        OLED_Set_Pos(i*8,7-x); 
                        temp=0x00;
                        for(j=0;j<7;j++)
                        {
                                OLED_WR_Byte(temp,1);
                        }
                }
                OLED_Set_Pos(i*8,7-(high/8));
                temp=0xff>>(high%8);
                for(j=0;j<7;j++)
                {
                        OLED_WR_Byte(temp,1);
                }
        }
}

void showbar5()
{                                
  unsigned char i,j,x,p,high,tigh,temp,itemp;
        xdata unsigned char dis_rdata[16]; 
        for(i=0;i<16;i++)          //��ȡFFTת������
        {
                float t0=0;
                t0=sqrt(pow((s[i  ].real+s[i+1].real),2)+pow((s[i  ].imag+s[i+1].imag),2))/2;
                dis_rdata[i]=(unsigned char)t0;
        }
        OLED_Display_On();
        for(i=0;i<16;i++)
        {
                itemp=high=0;
                itemp=high=dis_rdata[i];
                high=high/5;
                for(x=0;x<8;x++)
                {
                        OLED_Set_Pos(i*8,7-x); 
                        temp=0xff;
                        for(j=0;j<8;j++)
                        {
                                OLED_WR_Byte(temp,1);
                        }
                }
                if(high>64)high=64;
                p=high/8;
                tigh=high%8;
                if(p==0)
                {
                        p=1;
                        temp=~0x80;
                }
                else temp=~0x88;
                for(x=0;x<p;x++)
                {
                        OLED_Set_Pos(i*8,7-x); 
                        for(j=0;j<7;j++)
                        {
                                OLED_WR_Byte(temp,1);
                        }
                }
        }
}

/*������*/
void main()                                                                     
{
        int N=64,i,k;                 //������ʼ����64��FFT����
        float offset;
        
        TMOD=0X01;                      //��ʱ������ģʽ1
        TH0=(65535-10000)/256;           //������ʱʱ��
        TL0=(65535-10000)%256;
        TR0=1;                     //������ʱ��0
        ET0=1;                 //������ʱ��0�ж�
        EA=1;                 //�����ж�
        
        OLED_Init();  		//OLED��ʼ��
        OLED_Clear();
        
        P1ASF=0x01;                         //P1.0����ADʹ��
        P1M0 = 0x01;                  //0000��0001����A/Dת����P1.x�ڣ�����Ϊ��©
        P1M1 = 0x01;                 //0000��0001 P1.0����Ϊ��©���Ͽ��ڲ���������
		ADC_CONTR = 0xC8;			 //���ò�����Ϊ35kHz����
        while(!(ADC_CONTR&0x10));
        offset=((float)ADC_RES*4+(float)(ADC_RESL%0x04)); //���Ľ���ߣ�λ���ƣ�λ���ͣ�λ���䣬Ȼ�����
        while(1)
        {                
			if(P3==(P3&0xFE))IAP_CONTR=0x60;                
            for(i=0;i<N;i++)                                      //�ɼ���Ƶ�ź�
            { 
               		ADC_CONTR=0xC8;                                         //35KHz����������
                    while(!(ADC_CONTR&0x10));
                    s[i].real=((float)ADC_RES*4+(float)(ADC_RESL%0x04)-offset);
                 	s[i].imag=0;
            } 
			FFT(s,N);                        //����FFT�������б任
            EA=0;
            if(sb0==0)                        //ģʽ���ڰ�ť����
           	{
                    delay_ms(15);
                    if(sb0==0)
                    {
                            while(!sb0);
                            delay_ms(15);
                            k+=1;
                            if(k==6)k=0;
                    }
             }
             switch(k)                        //��ʾƵ��
             {
                      case 0:showbar0();break;                        //��ʱ��ñ����
                      case 1:showbar1();break;                        //����������
                      case 2:showbar2();break;                        //�Ⱥ�������
                      case 3:showbar3();break;                        //��ʱ��ñ����ȡ��
                      case 4:showbar4();break;                        //����������ȡ��
                      case 5:showbar5();break;                        //�Ⱥ�������ȡ��
             }
             EA=1;
        }
}

void ys_l()interrupt 1
{    
        TH0=(65535-10000)/256;                //������ʱʱ��
        TL0=(65535-10000)%256;
}
