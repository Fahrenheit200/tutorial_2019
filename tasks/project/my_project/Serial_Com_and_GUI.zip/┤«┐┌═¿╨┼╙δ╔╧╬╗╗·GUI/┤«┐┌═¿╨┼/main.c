#include<reg51.h>
#include<string.h>
#define uchar unsigned char 
#define uint unsigned int
#define BufferLength 32
uchar Buffer[BufferLength] = {0};
bit flag = 1;

bit SendByte(uchar byte)
{
	SBUF = byte;
	while(TI == 0);
	TI = 0;
	return 1;
}

bit SendString(uchar *pString)
{
	uint i, length;
	length = strlen(pString);
	for(i = 0; i<length; i++)
		SendByte(*(pString + i));
	return 1;
}

void main()
{
	TMOD = 0x20;
	SCON = 0x50;
	TL1 = 0xFD;
	TH1 = 0xFD;
	TR1 = 1;
	EA = 1;
	ES = 1;

	while(1)
	{
		while(flag);
		flag = 1;
		SendString("Little Star \n");  
		SendString("Two Tigers \n");
		SendString("Happy Birthday \n");
		SendString("Mother Best \n");
		SendString("Worms Fly \n");
		SendString("Gourd Baby \n");
		SendString("Song of Joy \n");
		SendString("Windmill \n");
		SendString("Happy New Year \n");
		SendString("Jingle Bells \n");
	}
}

void SerialReceive() interrupt 4
{
	static uchar i = 0;
	if(RI)
	{
	RI = 0;
	Buffer[i] = SBUF;
	i++;
	if(i == BufferLength)
		i = 0;
	flag = 0;
	}
}







