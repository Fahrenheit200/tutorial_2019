#include "LCD1602.h"
void LCD1602_delay_ms(unsigned int n);
void LCD1602_write_com(unsigned char com);
void LCD1602_write_data(unsigned char dat);
void LCD1602_write_word(unsigned char cmd, unsigned char *s);
void Init_LCD1602();
void LCD1602_write_Num(unsigned char charcmd, unsigned long dat);
//****************************************************
//MS��ʱ����(22M�����²���)
//****************************************************
void LCD1602_delay_ms(unsigned int n)
{
	unsigned int  i,j;
	for(i=0;i<n;i++)
		for(j=0;j<223;j++);
}

//****************************************************
//дָ��
//****************************************************
void LCD1602_write_com(unsigned char com)
{
	//WaitForEnable() ;
	LCD1602_RS = 0;
	LCD1602_delay_ms(10);
	LCD1602_EN = 1;
	LCD1602_PORT = com;
	LCD1602_delay_ms(10);
	LCD1602_EN = 0;
}

//****************************************************
//д����
//****************************************************
void LCD1602_write_data(unsigned char dat)
{
   // WaitForEnable() ;
	LCD1602_RS = 1;
	LCD1602_delay_ms(10);	
	LCD1602_PORT = dat;
	LCD1602_EN = 1;
	LCD1602_delay_ms(10);
	LCD1602_EN = 0;
}

//****************************************************
//����д�ַ�
//****************************************************
void LCD1602_write_word(unsigned char cmd, unsigned char *s)
{
	LCD1602_write_com(cmd);
	while(*s>0)
	{
		LCD1602_write_data(*s);
		s++;
	}
}

void Init_LCD1602()
{
	LCD1602_EN = 0;
	LCD1602_RW = 0;						//����Ϊд״̬
	LCD1602_write_com(0x38);			//��ʾģʽ�趨
	LCD1602_write_com(0x0c);			//������ʾ������������á������˸����
	LCD1602_write_com(0x06);			//дһ���ַ���ָ���һ
	LCD1602_write_com(0x01);			//����ָ��
}
void LCD1602_write_Num(unsigned char cmd, unsigned long dat)
{
	char s[8];
	s[0]=(dat%10000000/1000000+48);
	s[1]=(dat%1000000/100000+48);	
	s[2]=(dat%100000/10000+48);	
	s[3]=(dat%10000/1000+48);	
	s[4]=(dat%1000/100+48);	
	s[5]=(dat%100/10+48);	
	s[6]=(dat%10+48);
	s[7]=0;
    LCD1602_write_word(cmd, s);
}

