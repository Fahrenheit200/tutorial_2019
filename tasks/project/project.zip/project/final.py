import serial
import binascii
try:
    portx = "COM7"
    bps = 4800
    timex = 2
    ser = serial.Serial(portx, bps, timeout=timex, parity=serial.PARITY_NONE)
    print("串口详情参数：", ser)
    #随便发些东西启动串口通信
    data=b'ttt'
    data_hex=binascii.hexlify(data)
    ser.write(data_hex)
    print("歌单：")
    music_name=ser.readlines()
    #打印歌单
    for i in range(0,len(music_name)):
        print(music_name[i].decode())
except:
    print("Error!")