
unsigned char n=0; //index for beat
unsigned char end=0,stop=0; // end/stop a song
unsigned char p,m; 
unsigned char i=0; //index for frequency
int music_to_play=1; // Currently playing music

int TOTAL = 10; // total music

TAB[8]={0x7f,0x3f,0x1f,0x0f,0x07,0x03,0x01,0x00}; // for spectrum


#include <REG51.H>
#include <INTRINS.H>
#include "codetab.h" // wold table for OLED
#include "LQ12864.h" //head file for OLED
#include "mymusic.c" // store music
#include "key.h" //check for key press


sbit Beep =  P1^5;
//
sbit SRCLK=P3^6;
sbit RCLK=P3^5;
sbit SER=P3^4;

void UsartInit()
{
    SCON=0X50;			
    PCON=0X80;			
    TH1=0XF3;				
    TL1=0XF3;
    ES=1;						
    EA=1;						
    TR1=1;					
}
//special for music delay
void music_delay (unsigned char m)
{
    unsigned i=3*m;
    while(--i);
}
//lighening the lattice
void Hc595SendByte(unsigned char dat)
{
	unsigned char a;
	SRCLK=0;
	RCLK=0;
	for(a=0;a<8;a++)
	{
		SER=dat>>7;
		dat<<=1;

		SRCLK=1;
		_nop_();
		_nop_();
		SRCLK=0;	
	}

	RCLK=1;
	_nop_();
	_nop_();
	RCLK=0;
}
void Init()
{
	TMOD=0X21;
    TH0=TH0_temp;
    TL0=TL0_temp;
    IE=0x82;
    led=0;
	i=0; 
	end=0;
	stop=0;
}
// main function for playing music
// first parameter is frequency table
// second parameter is beat table
void display(unsigned char tone_tab[],unsigned char beat_tab[])
{
    unsigned char temp,t=7;
	end=0;
	if(stop==1) i=0;
    while(!end&&!stop)
    {
        p=fre_tab[tone_tab[i]+t];
        if(p==0x00)
        {
            end=1; i=0;
        }
        else
        {
			P0=TAB[(tone_tab[i]+7)%7];
            m=fre_tab[tone_tab[i]+t];
            temp=beat_tab[i];
            if(temp==8)
            {
                temp=5;
            }
            if(temp==16)
            {
                temp=6;
            }
            if(temp==32)
            {
                temp=7;
            }
            n=pai_tab[temp-1];
            i++;
            TR0=1;
            while(n!=0) Beep=~Beep,music_delay(m);
            TR0=0;
        }
        keypros_stop();
        keypros_next();
		keypros_quick();
		keypros_slow();
    }
	keypros_stop();
}

// which music to play
void play_tab(int music_index)
{
    switch (music_index)
    {
    case 1:
        display(two_tiger_tone,two_tiger_beat);
		P0=0xff;
		delayms(500);
        break;
    case 2:
        display(x,y);
		P0=0xff;
		delayms(500);
        break;
    case 3:
        display(my_country_and_i_tone,my_country_and_i_beat);
		P0=0xff;
		delayms(500);
        break;
	case 4:
		display(chrysanthemum_terrace_tone,chrysanthemum_terrace_beat);
		P0=0xff;
		delayms(500);
		break;
	case 5:
		display(city_of_sky_tone,city_of_sky_beat);
		P0=0xff;
		delayms(500);
		break;
	case 6:
		display(happy_birthday_tone,happy_birthday_beat);
		P0=0xff;
		delayms(500);
		break;
	case 7:
		display(little_star_tone,little_star_beat);
		P0=0xff;
		delayms(500);
		break;
	case 8:
		display(one_cent_tone,one_cent_beat);
		P0=0x00;
		delayms(500);
		break;
	case 9:
		display(little_donkey_tone,little_donkey_beat);
		P0=0x00;
		delayms(500);
		break;
	case 10:
		display(whitewasher_tone,whitewasher_beat);
		P0=0x00;
		delayms(500);
		break;
    default:
        break;
    }
}
void main()
{
	unsigned char a;
    Init();
	OLED_Init();	
	UsartInit();  
	Hc595SendByte(0x03);
    while(1)
    {
        //keypros();
		    for(a=2; a<6; a++)
    {
        OLED_P16x16Ch(a*16,0,a-2);
    }
	OLED_P8x16Str(0,6," >> ||> >>> <<<");
	if(music_to_play<TOTAL+1 && stop==0)
	{
		OLED_P6x8Str(0,4,music_name[music_to_play-1]);
		play_tab(music_to_play);
		if(end==1) { music_to_play++;  OLED_CLS(); if(music_to_play==TOTAL+1) music_to_play=1;}
		keypros_stop();
	}
	keypros_stop();
    }
}

//Serial communication interruption
void Usart() interrupt 4
{
	
	unsigned char ii,jj;
    unsigned char  count=0x30;
    RI = 0;
    ii=0;
	jj=0;

        while(jj!=10)
        {
            ii=0;
            SBUF=count;
            while(!TI);
            TI=0;
            SBUF='.';
            while(!TI);
            TI=0;
            count++;
			//send music name jj
            while(music_name[jj][ii]!='\0')
            {
                    SBUF=music_name[jj][ii];
                    while(!TI);
                    TI=0;
                    ii++;
            }
            SBUF=0x0a;
            while(!TI);
            TI=0;
            jj++;
        }
	TMOD=0x01;
	TR1=0;
}
// Music play , timer interruption
void int0()  interrupt 1
{
    TH0=TH0_temp;
    TL0=TL0_temp;
    n--;
}
