sbit k_stop=P3^0; 
sbit k_next=P3^1;
sbit k_quick=P3^2;
sbit k_slow=P3^3;

sbit led=P2^0;

unsigned char TH0_temp=0xd8;
unsigned char TL0_temp=0xef;

void delayms(unsigned char x)
{
    unsigned char a,b,c;
    for(c=x; c>0; c--)
        for(b=142; b>0; b--)
            for(a=2; a>0; a--);
}
//stop the song
void keypros_stop()
{
    if(k_stop==0)
    {
        delayms(10);
        if(k_stop==0)
        {
			if(stop==0) stop=1;
			else stop=0;
            led=~led;
        }
        while(!k_stop);
    }
}
// play next song
void keypros_next()
{
    if(k_next==0)
    {
        delayms(10);
        if(k_next==0)
        {
            end=1; i=0;
        }
        while(!k_next);
    }
}
//quicker
void keypros_quick()
{
	if(k_quick==0)
    {
        delayms(10);
        if(k_quick==0)
        {
            TL0_temp+=0xb8;
			TH0_temp+=0x0b;
        }
        while(!k_quick);
    }
}
//slower
void keypros_slow()
{
	if(k_slow==0)
    {
        delayms(10);
        if(k_slow==0)
        {
            TL0_temp-=0xb8;
			TH0_temp-=0x0b;
        }
        while(!k_slow);
    }
}