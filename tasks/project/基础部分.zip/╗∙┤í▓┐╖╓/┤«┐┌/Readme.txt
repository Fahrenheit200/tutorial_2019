## Title Here: Readme Tutorial

- Author: 黄浩东
- Revised: 黄浩东
- Date: 2019-11-02
- Version: 1.0.0
- Abstract: 实现串口通信

### Functions:
	参考CSDN：https://blog.csdn.net/misslxy/article/details/82849193
	实现串口通信，显示歌单并在上位机点播歌曲
### Interfaces:
        /* CheckPortSetting
        * 检查串口是否设置
        */ 
        private bool CheckPortSetting();

        /* sp_DataReceived
        * 显示歌单
        */
        private void sp_DataReceived(object sender,EventArgs e);

        /* music_Click
        * 点播音乐
        */
        private void music_Click(object sender, EventArgs e);
 
### Depend Libraries:
        using System;
        using System.Collections.Generic;
        using System.ComponentModel;
        using System.Data;
        using System.Drawing;
        using System.Linq;
        using System.Text;
        using System.Threading.Tasks;
        using System.Windows.Forms;
        using System.IO.Ports;
        using System.IO;
        using System.Timers;
