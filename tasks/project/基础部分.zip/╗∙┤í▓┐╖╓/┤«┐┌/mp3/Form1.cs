﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;
using System.Timers;

namespace mp3
{
    public partial class Form1 : Form
    {
        private SerialPort sp = new SerialPort();
        bool isOpen = false;
        bool isSetProperty = false;
        bool isHex = false;
        bool isget = false;
        bool printHex = false;
        String RecvData = null;
        float cbxStopBits = 1;
        int cbxDataBits = 8;
        String cbxParity = "None";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.MaximumSize = this.Size;
            this.MinimumSize = this.Size;
            this.MaximizeBox = false;
            for (int i = 0; i < 1; ++i)
                cbxComPort.Items.Add("");
            cbxComPort.SelectedIndex = 0;
            cbxBaudRate.Items.Add("9600");
            cbxBaudRate.Items.Add("38400");
            cbxBaudRate.Items.Add("115200");
            cbxBaudRate.SelectedIndex = 0;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private bool CheckPortSetting()
        {
            if (cbxComPort.Text.Trim() == "") return false;
            if (cbxBaudRate.Text.Trim() == "") return false;
            return true;
        }
        private void sp_DataReceived(object sender,EventArgs e)
        {
            System.Threading.Thread.Sleep(300);
            this.Invoke((EventHandler)(delegate
            {
                if (isHex == false)
                {
                    Byte[] readBytes = new Byte[sp.BytesToRead];
                    sp.Read(readBytes, 0, readBytes.Length);
                    String decodedString = Encoding.GetEncoding("GB18030").GetString(readBytes);
                    tbxRecvData.Text = decodedString;
                    String[] getAry = decodedString.Split(new char[] { ':', '\n' });
                    if (!isget)
                    {
                        isget = true;
                        for (int j = 1; j < getAry.Length; j += 2)
                            cbxMusic.Items.Add(getAry[j]);
                    }
                }
                else
                {
                    Byte[] ReacivedData = new Byte[sp.BytesToRead];
                    sp.Read(ReacivedData, 0, ReacivedData.Length);
                    String ReavDataText = null;
                    string s = string.Empty;
                    for (int i = 0; i < ReacivedData.Length; i++)
                    {
                        ReavDataText += (ReacivedData[i].ToString());
                        s += (char)ReacivedData[i];
                    }
                    tbxRecvData.Text += ReacivedData;
                    ReavDataText = s;
                }
                sp.DiscardInBuffer();
            }));
        }
        private void SetPortProperty()
        {
            sp = new SerialPort();
            sp.PortName = cbxComPort.Text.Trim();
            sp.BaudRate = Convert.ToInt32((cbxBaudRate.Text.Trim()));
            sp.StopBits = StopBits.One;
            sp.DataBits = 8;
            sp.Parity = Parity.None;
            sp.ReadTimeout = -1;
            sp.RtsEnable = true;
            sp.DataReceived += new SerialDataReceivedEventHandler(sp_DataReceived);
            if (rbnHex.Checked)
            {
                isHex = true;
            }
            else
            {
                isHex = false;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if(isOpen == false)
            {
                if(!CheckPortSetting())
                {
                    MessageBox.Show("Serial without setting");
                }
                if(!isSetProperty)
                {
                    isSetProperty = true;
                    SetPortProperty();
                }
                try
                {
                    sp.Open();
                    isOpen = true;
                    btnOpen.Text = "关闭串口";
                    cbxBaudRate.Enabled = false;
                    cbxComPort.Enabled = false;
                }
                catch(Exception)
                {
                    isOpen = false;
                    MessageBox.Show("Serial open failed");
                }
            }
            else
                try
                {
                    sp.Close();
                    isOpen = false;
                    btnOpen.Text = "打开串口";
                    cbxBaudRate.Enabled = true;
                    cbxComPort.Enabled = true;
                }
                catch(Exception)
                {
                    ;
                }
        }


        private void button3_Click(object sender, EventArgs e)
        {
            bool comExistence = false;
            cbxComPort.Items.Clear();
            for (int i = 0; i < 10; ++i)
            {
                try
                {
                    SerialPort sp = new SerialPort("COM" + i.ToString());
                    sp.Open();
                    sp.Close();
                    cbxComPort.Items.Add("COM" + i.ToString());
                    comExistence = true;
                }
                catch (Exception) 
                {
                    continue;
                }
            }
            if(comExistence)
            {
                cbxComPort.SelectedIndex = 0;
            }
            else
            {
                MessageBox.Show("not found!");
            }
        }

        private void cbxComPort_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            if (isOpen == true)
            {
                try
                {
                    System.Text.UTF8Encoding utf8 = new System.Text.UTF8Encoding();
                    Byte[] writeBytes = utf8.GetBytes(tbxSendData.Text);
                    sp.Write(writeBytes, 0, writeBytes.Length);
                    //tbxSendData.Text = "";
                }
                catch (Exception)
                {
                    MessageBox.Show("Send error!");
                }
            }
            else
            {
                MessageBox.Show("Serial hasn't opened");
            }
        }

        private void rbnHex_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnHex.Checked)
            {
                isHex = true;
            }
            else
            {
                isHex = false;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(rbnsend.Checked)
            {
                printHex = true;
            }
            else
            {
                printHex = false;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Label.Text = "Author:Holdon";
        }

        private void music_Click(object sender, EventArgs e)
        {
            if (isOpen)
            {
                if (!isget)
                {
                    try
                    {
                        tbxSendData.Text = "{Go}";
                        System.Text.UTF8Encoding utf8 = new System.Text.UTF8Encoding();
                        Byte[] writeBytes = utf8.GetBytes(tbxSendData.Text);
                        sp.Write(writeBytes, 0, writeBytes.Length);
                        music.Text = "播放";
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Send Error!");
                    }
                }
                else
                {
                    try
                    {
                        if (cbxMusic.SelectedIndex > 0)
                        {
                            tbxSendData.Text = "{C" + cbxMusic.SelectedIndex + "}";
                            System.Text.UTF8Encoding utf8 = new System.Text.UTF8Encoding();
                            Byte[] writeBytes = utf8.GetBytes(tbxSendData.Text);
                            sp.Write(writeBytes, 0, writeBytes.Length);
                        }
                    }
                    catch(Exception)
                    {
                        MessageBox.Show("Send Error!");
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tbxRecvData.Text = " ";
        }
    }
}
