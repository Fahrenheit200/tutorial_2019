﻿namespace mp3
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbxComPort = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbxBaudRate = new System.Windows.Forms.ComboBox();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnCheck = new System.Windows.Forms.Button();
            this.rbnHex = new System.Windows.Forms.CheckBox();
            this.tbxRecvData = new System.Windows.Forms.TextBox();
            this.tbxSendData = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.rbnsend = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbxMusic = new System.Windows.Forms.ComboBox();
            this.music = new System.Windows.Forms.Button();
            this.Label = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbxComPort);
            this.groupBox1.Location = new System.Drawing.Point(352, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(130, 49);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "串口设置";
            // 
            // cbxComPort
            // 
            this.cbxComPort.FormattingEnabled = true;
            this.cbxComPort.Location = new System.Drawing.Point(3, 20);
            this.cbxComPort.Name = "cbxComPort";
            this.cbxComPort.Size = new System.Drawing.Size(121, 20);
            this.cbxComPort.TabIndex = 0;
            this.cbxComPort.SelectedIndexChanged += new System.EventHandler(this.cbxComPort_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbxBaudRate);
            this.groupBox2.Location = new System.Drawing.Point(352, 67);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(130, 49);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "波特率设置";
            // 
            // cbxBaudRate
            // 
            this.cbxBaudRate.FormattingEnabled = true;
            this.cbxBaudRate.Location = new System.Drawing.Point(3, 20);
            this.cbxBaudRate.Name = "cbxBaudRate";
            this.cbxBaudRate.Size = new System.Drawing.Size(121, 20);
            this.cbxBaudRate.TabIndex = 0;
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(352, 171);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(130, 23);
            this.btnOpen.TabIndex = 2;
            this.btnOpen.Text = "打开串口";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnCheck
            // 
            this.btnCheck.Location = new System.Drawing.Point(352, 133);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(130, 23);
            this.btnCheck.TabIndex = 4;
            this.btnCheck.Text = "检测串口";
            this.btnCheck.UseVisualStyleBackColor = true;
            this.btnCheck.Click += new System.EventHandler(this.button3_Click);
            // 
            // rbnHex
            // 
            this.rbnHex.AutoSize = true;
            this.rbnHex.BackColor = System.Drawing.SystemColors.Control;
            this.rbnHex.Location = new System.Drawing.Point(352, 200);
            this.rbnHex.Name = "rbnHex";
            this.rbnHex.Size = new System.Drawing.Size(72, 16);
            this.rbnHex.TabIndex = 5;
            this.rbnHex.Text = "HEX Recv";
            this.rbnHex.UseVisualStyleBackColor = false;
            this.rbnHex.CheckedChanged += new System.EventHandler(this.rbnHex_CheckedChanged);
            // 
            // tbxRecvData
            // 
            this.tbxRecvData.Location = new System.Drawing.Point(12, 12);
            this.tbxRecvData.Multiline = true;
            this.tbxRecvData.Name = "tbxRecvData";
            this.tbxRecvData.Size = new System.Drawing.Size(334, 213);
            this.tbxRecvData.TabIndex = 6;
            // 
            // tbxSendData
            // 
            this.tbxSendData.Location = new System.Drawing.Point(12, 231);
            this.tbxSendData.Multiline = true;
            this.tbxSendData.Name = "tbxSendData";
            this.tbxSendData.Size = new System.Drawing.Size(334, 111);
            this.tbxSendData.TabIndex = 7;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(271, 319);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "发送";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // rbnsend
            // 
            this.rbnsend.AutoSize = true;
            this.rbnsend.Location = new System.Drawing.Point(352, 222);
            this.rbnsend.Name = "rbnsend";
            this.rbnsend.Size = new System.Drawing.Size(72, 16);
            this.rbnsend.TabIndex = 9;
            this.rbnsend.Text = "HEX Send";
            this.rbnsend.UseVisualStyleBackColor = true;
            this.rbnsend.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbxMusic);
            this.groupBox3.Location = new System.Drawing.Point(352, 244);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(130, 49);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "音乐列表";
            // 
            // cbxMusic
            // 
            this.cbxMusic.FormattingEnabled = true;
            this.cbxMusic.Location = new System.Drawing.Point(3, 20);
            this.cbxMusic.Name = "cbxMusic";
            this.cbxMusic.Size = new System.Drawing.Size(121, 20);
            this.cbxMusic.TabIndex = 1;
            // 
            // music
            // 
            this.music.Location = new System.Drawing.Point(352, 299);
            this.music.Name = "music";
            this.music.Size = new System.Drawing.Size(130, 23);
            this.music.TabIndex = 11;
            this.music.Text = "获取音乐";
            this.music.UseVisualStyleBackColor = true;
            this.music.Click += new System.EventHandler(this.music_Click);
            // 
            // Label
            // 
            this.Label.AutoSize = true;
            this.Label.Location = new System.Drawing.Point(406, 330);
            this.Label.Name = "Label";
            this.Label.Size = new System.Drawing.Size(41, 12);
            this.Label.TabIndex = 12;
            this.Label.Text = "Author";
            this.Label.Click += new System.EventHandler(this.label1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(271, 202);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 13;
            this.button2.Text = "清除";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(494, 347);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Label);
            this.Controls.Add(this.music);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.rbnsend);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbxSendData);
            this.Controls.Add(this.tbxRecvData);
            this.Controls.Add(this.rbnHex);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "MP3上位机";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cbxComPort;
        private System.Windows.Forms.ComboBox cbxBaudRate;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.CheckBox rbnHex;
        private System.Windows.Forms.TextBox tbxRecvData;
        private System.Windows.Forms.TextBox tbxSendData;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox rbnsend;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox cbxMusic;
        private System.Windows.Forms.Button music;
        private System.Windows.Forms.Label Label;
        private System.Windows.Forms.Button button2;
    }
}

