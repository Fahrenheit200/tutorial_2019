#ifndef __ENCODE_H
#define __ENCODE_H
#include "sys.h"

#define ENCODER_TIM_PERIOD (u16)(65535) 

int Read_Encoder(u8 TIMX);
void Encoder_Init_TIM2(void);
void Encoder_Init_TIM3(void);
void Encoder_Init_TIM4(void);
void Encoder_Init_TIM5(void);

#endif

