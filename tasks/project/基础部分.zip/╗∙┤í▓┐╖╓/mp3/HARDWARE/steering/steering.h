#ifndef __STEERING_H
#define __STEERING_H
#include "sys.h"
#include "pca9685.h"
#define hand_zhua  (PCA_MG9XX(0,0,56,0,1))
#define hand_fang	 (PCA_MG9XX(0,0,30,0,1))
#define hand_song  (PCA_MG9XX(0,0,2,0,1))
#define load_up    (PCA_MG9XX(1,0,23,0,1))
#define load_down  (PCA_MG9XX(1,0,155,0,1))
#define raise_up   (PCA_MG9XX(2,0,24,0,1))
#define raise_down (PCA_MG9XX(2,0,63,0,1))
#define seize_on	 (PCA_MG9XX(3,0,48,0,1))
#define seize_off	 (PCA_MG9XX(3,0,30,0,1))
#define shot TIM1->CCR4
void TIM8_PWM_init(u16 arr,u16 psc);
int angle(int x);
#endif

