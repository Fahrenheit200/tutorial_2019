#include "steering.h"

void TIM1_PWM_init(u16 arr,u16 psc)
{
	RCC->APB2ENR|=1<<11;//TIM1ʱ��ʹ��
	RCC->APB2ENR|=1<<2;
	RCC->APB2ENR|=1<<0;//ʹ��AFIO��GPIOAʱ��
	
	TIM1->BDTR|=1<<15;//PWM���ʹ��
	
	GPIOA->CRH&=0XFFFF0FF0;
	GPIOA->CRH|=0X0000B00B;//PA8,11�������
	
	TIM1->ARR=arr;		 
	TIM1->PSC=psc;
	
	TIM1->CCMR1|=6<<4;  	//CH1~4 PWM2ģʽ		 
	TIM1->CCMR1|=1<<3; 	  //CH1~4 Ԥװ��ʹ��	
	TIM1->CCMR1|=6<<12;   
	TIM1->CCMR1|=1<<11; 	 
	TIM1->CCMR2|=6<<4;  	 		 
	TIM1->CCMR2|=1<<3; 	   	   
	TIM1->CCMR2|=6<<12;  	 
	TIM1->CCMR2|=1<<11; 	
	//TIM1->CCER|=1<<0;   //OC4 ���ʹ��
	//TIM1->CCER|=1<<4;
	//TIM1->CCER|=1<<8;
	TIM1->CCER|=1<<12;
	
	TIM1->CR1|=0x0080;   	//ARPEʹ�� 
	TIM1->CR1|=0x01;
}



int angle (int y)//�Ƕ�ת��PWM
{
	return (50+(y*10)/9);
}

