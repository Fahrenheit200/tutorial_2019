#ifndef __EXIT_H
#define __EXIT_H
#include "sys.h"

#define KEY	PBin(2) //PB2
#define KEY_PRES 1	//KEY����

void key_init(void);//IO��ʼ��
void exit_init(void);
extern int INDEX;
extern int FIND;
#endif 

