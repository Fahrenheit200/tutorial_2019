#ifndef __MOTOR_H
#define __MOTOR_H
#include "sys.h"
#include "control.h"

#define LEFT TIM8->CCR1
#define RIGHT TIM8->CCR2
#define BEHIND TIM8->CCR3
#define RUB TIM8->CCR4

#define LIN1 PBout(12)
#define LIN2 PBout(13)
#define RIN1 PBout(14)
#define RIN2 PBout(15)
#define BIN1 PBout(8)
#define BIN2 PBout(9)

enum
{
	left,
	right,
	behind,
	rub,
};

void TIM1_PWM_init(u16 arr,u16 psc);
void motor_init(void);
void Motor(float TP1,float TP2,float TP3);

#endif

