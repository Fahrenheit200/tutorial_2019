#ifndef __CONTROL_H
#define __CONTROL_H

#include "sys.h"
#include "motor.h"
#include "timer.h"
#include "encode.h"
#include "usart.h"
#include "usart2.h"
#include "steering.h"

#define num_root2  1.414214              //v2
#define num_root3  1.732051              //v3
#define num_root2_part2   0.707106            //(v2)/2
#define num_root3_part2   0.866025            //(v3)/2
#define num_part2         0.5                 //1/2
#define pi   3.141593
#define standard_num      7.320508      //1000\(100*v3\2+100\2)
#define standard_theta    66.666667              //1000\15 
#define R 1
#define maxPWM 4999
extern int ms_10;
void move(int V_x ,int V_y ,int V_theta);
struct control
{
	float Bias;
	float Last_Bias;
	float LLast_Bias;
	float PWM;
	float encoder;
	float target;
	float integral;
};
extern struct control l,r,b,f;
extern int x_Bias,y_Bias,l_Bias,x_Last_Bias,y_Last_Bias,l_Last_Bias,x_LLast_Bias,y_LLast_Bias,l_LLast_Bias;
extern float Kp,Ki,Kd,Kp_1,Ki_1,Kd_1,Kp_2,Ki_2,Kd_2,Kp_3,Ki_3,Kd_3;
extern int vx,vy,vw;
void control_init(void);
void TIM6_init(u16 arr,u16 psc);
void TIM7_init(u16 arr,u16 psc);
int abs(int x);
int Xianfu_Pwm(int x);
void Set_Pwm(void);
void PI_goahead(void);
#endif

