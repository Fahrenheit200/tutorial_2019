#ifndef __KEY_H
#define __KEY_H	 
#include "stm32f10x.h"


#define Hang_00_L  GPIO_ResetBits(GPIOB, GPIO_Pin_7)//��00
#define Hang_00_H  GPIO_SetBits(GPIOB, GPIO_Pin_7)
 
#define Hang_01_L  GPIO_ResetBits(GPIOB, GPIO_Pin_6)//��01
#define Hang_01_H  GPIO_SetBits(GPIOB, GPIO_Pin_6)
 
#define Hang_02_L  GPIO_ResetBits(GPIOB, GPIO_Pin_5)//��02
#define Hang_02_H  GPIO_SetBits(GPIOB, GPIO_Pin_5)
 
#define Hang_03_L  GPIO_ResetBits(GPIOB, GPIO_Pin_4)//��03
#define Hang_03_H  GPIO_SetBits(GPIOB, GPIO_Pin_4)
 
#define Lie_00_V GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)//��00
#define Lie_01_V GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_2)//��01
#define Lie_02_V GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)//��02
#define Lie_03_V GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)//��03

#define  jpys   1   //�궨�壬Լ��jpys==20�������Ժ������ֲ


void KEY_init(void);//IO��ʼ��
u8 KEY_Scan(u8 mode);  	//����ɨ�躯��

#endif


