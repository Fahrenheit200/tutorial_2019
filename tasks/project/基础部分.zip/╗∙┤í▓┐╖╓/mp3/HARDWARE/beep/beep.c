#include "beep.h"
#include "delay.h"
#include "key.h"
#include "oled.h"
#include<stdio.h>
#include<string.h>
//////////////////////////////////////////////////////////////////////////////////
u8 id = 0;
u8 temp = 0;
u8 pause = 1;//�ж��Ƿ���ͣ���Ż��߼������� 
u8 beep_switch=0;
//u16 beep_time=0;

//������һ���ṹ�����飬������������������� 
sList Mysong[10]={
	{"���֮��",194,{{M1,3*TT/8},{L7,TT/8},{M1,TT/4},{M3,TT/4},{L7,3*TT/4},{L3,TT/4},{L6,3*TT/8},{L5,TT/8},{L6,TT/4},{M1,TT/4},
{L5,3*TT/4},{L3,TT/4},{L4,3*TT/8},{L3,TT/8},{L4,TT/8},{M1,TT/8},{M1,TT/4},{L3,3*TT/4},{M1,TT/4},
{L7,3*TT/8},{L4,TT/8},{L4,TT/4},{L7,TT/4},{L7,TT/2},{0,TT/4},{L6,TT/8},{L7,TT/8},
{M1,3*TT/8},{L7,TT/8},{M1,TT/4},{M3,TT/4},{L7,3*TT/4},{L3,TT/8},{L3,TT/8},{L6,TT/2},{0,TT/4},{M1,TT/8},{M2,TT/8},
{M3,3*TT/8},{M2,TT/6},{M3,TT/6},{M4,TT/6},{M5,TT/8},{M2,3*TT/4},{L5,TT/4},
{M2,TT/16},{M1,TT/16},{L7,TT/16},{M1,TT/16},{M1,TT/4},{M1,TT/8},{M2,TT/4},{M3,TT/8},{M3,TT},
{L6,TT/8},{L7,TT/8},{M1,TT/4},{L7,TT/8},{M1,TT/8},{M2,TT/8},
{M1,3*TT/8},{L5,TT/8},{L5,TT/2},{M4,TT/4},{M3,TT/4},{M2,TT/4},{M1,TT/4},
{M3,3*TT/4},{L6,TT/8},{L7,TT/8},{M1,3*TT/8},{L7,TT/8},{M1,TT/4},{M3,TT/4},{L7,3*TT/4},{L3,TT/4},
{L6,3*TT/8},{L5,TT/8},{L6,TT/4},{M1,TT/4},{L5,3*TT/4},{L3,TT/4},
{L4,TT/4},{M1,TT/8},{L7,TT/8},{L7,TT/4},{M1,TT/4},{M2,TT/4},{M3,TT/8},{M1,TT/8},{M1,TT/2},
{M1,TT/8},{L7,TT/8},{L6,TT/4},{L7,TT/4},{L5,TT/4},
{M1,3*TT/8},{L7,TT/8},{M1,TT/4},{M3,TT/4},{L7,3*TT/4},{L3,TT/4},{L6,3*TT/8},{L5,TT/8},{L6,TT/4},{M1,TT/4},
{L5,3*TT/4},{L3,TT/4},{L4,3*TT/8},{L3,TT/8},{L4,TT/8},{M1,TT/8},{M1,TT/4},{L3,3*TT/4},{M1,TT/4},
{L7,3*TT/8},{L4,TT/8},{L4,TT/4},{L7,TT/4},{L7,TT/2},{0,TT/4},{L6,TT/8},{L7,TT/8},
{M1,3*TT/8},{L7,TT/8},{M1,TT/4},{M3,TT/4},{L7,3*TT/4},{L3,TT/8},{L3,TT/8},{L6,TT/2},{0,TT/4},{M1,TT/8},{M2,TT/8},
{M3,3*TT/8},{M2,TT/6},{M3,TT/6},{M4,TT/6},{M5,TT/8},{M2,3*TT/4},{L5,TT/4},
{M2,TT/16},{M1,TT/16},{L7,TT/16},{M1,TT/16},{M1,TT/4},{M1,TT/8},{M2,TT/4},{M3,TT/8},{M3,TT},
{L6,TT/8},{L7,TT/8},{M1,TT/4},{L7,TT/8},{M1,TT/8},{M2,TT/8},
{M1,3*TT/8},{L5,TT/8},{L5,TT/2},{M4,TT/4},{M3,TT/4},{M2,TT/4},{M1,TT/4},
{M3,3*TT/4},{L6,TT/8},{L7,TT/8},{M1,3*TT/8},{L7,TT/8},{M1,TT/4},{M3,TT/4},{L7,3*TT/4},{L3,TT/4},
{L6,3*TT/8},{L5,TT/8},{L6,TT/4},{M1,TT/4},{L5,3*TT/4},{L3,TT/4},
{L4,TT/4},{M1,TT/8},{L7,TT/8},{L7,TT/4},{M1,TT/4},{M2,TT/4},{M3,TT/8},{M1,TT/8},{M1,TT/2},
{M1,TT/8},{L7,TT/8},{L6,TT/4},{L7,TT/4},{L5,TT/4},
{L6,TT},
{0,0},}},
	{"�Һ��ҵ����",231,{{M5,TT/8},{M6,TT/8},{M5,TT/8},{M4,TT/8},{M3,TT/8},{M2,TT/8},{M1,3*TT/8},{L5,3*TT/8},
{M1,TT/8},{M3,TT/8},{H1,TT/8},{M7,TT/8},{M6,3*TT/16},{M3,TT/16},{M5,3*TT/8},{M5,3*TT/8},
{M6,TT/8},{M7,TT/8},{M6,TT/8},{M5,TT/8},{M4,TT/8},{M3,TT/8},{M2,3*TT/8},{L6,3*TT/8},
{L7,TT/8},{L6,TT/8},{L5,TT/8},{M5,TT/8},{M1,3*TT/16},{M2,TT/16},{M3,3*TT/8},{M3,3*TT/8},
{M5,TT/8},{M6,TT/8},{M5,TT/8},{M4,TT/8},{M3,TT/8},{M2,TT/8},{M1,3*TT/8},{L5,3*TT/8},
{M1,TT/8},{M3,TT/8},{H1,TT/8},{M7,TT/8},{H2,3*TT/16},{H1,TT/16},{M6,3*TT/8},{M6,3*TT/8},
{H1,TT/8},{M7,TT/8},{M6,TT/8},{M5,3*TT/8},{M6,TT/8},{M5,TT/8},{M3,TT/8},{M3,3*TT/8},
{L7,TT/4},{L6,TT/8},{L5,TT/4},{M2,TT/8},{M1,3*TT/8},{M1,3*TT/8},
{H1,TT/8},{H2,TT/8},{H3,TT/8},{H2,TT/8},{H1,TT/8},{M6,TT/8},{M7,TT/8},{M6,3*TT/16},{M3,TT/16},{M5,3*TT/8},{M5,3*TT/8},
{H1,TT/8},{H2,TT/8},{H3,TT/8},{H2,TT/8},{H1,TT/8},{M6,3*TT/8},{M7,TT/8},{M5,3*TT/16},{M3,TT/16},{M6,3*TT/8},{M6,3*TT/8},
{M5,TT/8},{M4,TT/8},{M3,TT/8},{M2,3*TT/8},{L7,TT/8},{L6,TT/16},{L6,TT/16},{L5,TT/8},{M3,3*TT/8},{M4,3*TT/8},{M2,TT/4},{M1,TT/8},{M1,3*TT/8},{M1,TT/4},{0,TT/8},
{M5,TT/8},{M6,TT/8},{M5,TT/8},{M4,TT/8},{M3,TT/8},{M2,TT/8},{M1,3*TT/8},{L5,3*TT/8},
{M1,TT/8},{M3,TT/8},{H1,TT/8},{M7,TT/8},{M6,3*TT/16},{M3,TT/16},{M5,3*TT/8},{M5,3*TT/8},
{M6,TT/8},{M7,TT/8},{M6,TT/8},{M5,TT/8},{M4,TT/8},{M3,TT/8},{M2,3*TT/8},{L6,3*TT/8},
{L7,TT/8},{L6,TT/8},{L5,TT/8},{M5,TT/8},{M1,3*TT/16},{M2,TT/16},{M3,3*TT/8},{M3,3*TT/8},
{M5,TT/8},{M6,TT/8},{M5,TT/8},{M4,TT/8},{M3,TT/8},{M2,TT/8},{M1,3*TT/8},{L5,3*TT/8},
{M1,TT/8},{M3,TT/8},{H1,TT/8},{M7,TT/8},{H2,3*TT/16},{H1,TT/16},{M6,3*TT/8},{M6,3*TT/8},
{H1,TT/8},{M7,TT/8},{M6,TT/8},{M5,3*TT/8},{M6,TT/8},{M5,TT/8},{M3,TT/8},{M3,3*TT/8},
{L7,TT/4},{L6,TT/8},{L5,TT/4},{M2,TT/8},{M1,3*TT/8},{M1,3*TT/8},
{H1,TT/8},{H2,TT/8},{H3,TT/8},{H2,TT/8},{H1,TT/8},{M6,TT/8},{M7,TT/8},{M6,3*TT/16},{M3,TT/16},{M5,3*TT/8},{M5,3*TT/8},
{H1,TT/8},{H2,TT/8},{H3,TT/8},{H2,TT/8},{H1,TT/8},{M6,3*TT/8},{M7,TT/8},{M5,3*TT/16},{M3,TT/16},{M6,3*TT/8},{M6,3*TT/8},
{M5,TT/8},{M4,TT/8},{M3,TT/8},{M2,3*TT/8},{L7,TT/8},{L6,TT/16},{L6,TT/16},{L5,TT/8},{M3,3*TT/8},{M4,3*TT/8},{M2,TT/4},{M1,TT/8},{M1,3*TT/8},{M1,TT/4},{0,TT/8},
{H1,TT/8},{H2,TT/8},{H3,TT/8},{H2,TT/8},{H1,TT/8},{M6,TT/8},{M7,TT/8},{M6,3*TT/16},{M3,TT/16},{M5,3*TT/8},
{H1,TT/8},{H2,TT/8},{H3,TT/8},{H2,TT/8},{H1,TT/8},{M6,TT/8},{M7,TT/8},{M5,3*TT/16},{M3,TT/16},{M6,3*TT/8},
{M5,TT/8},{M4,TT/8},{M3,TT/8},{M2,3*TT/8},{L7,TT/8},{L6,TT/8},{L5,TT/8},{M3,3*TT/16},{M5,3*TT/8},{H2,TT/4},{H1,TT/8},{H1,3*TT/8},{H1,3*TT/8},
{0,0},}},
	{"��ʿɽ��",249,{{L5,TT/8},{L6,TT/8},{M1,TT/8},{M2,TT/8},{M1,TT/8},{M2,TT/8},{M3,TT/8},{M3,TT/8},{M3,TT/8},{M3,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},
{M2,TT/8},{M3,TT/8},{M3,TT/8},{M3,TT/8},{M3,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},
{M2,3*TT/16},{M1,TT/16},{M1,TT/8},{L6,TT/8},{M1,3*TT/16},{M2,TT/16},{M2,TT/8},{M3,TT/16},
{M3,3*TT/8},{L5,TT/8},{L6,TT/8},{M1,TT/8},{M2,TT/8},{M1,TT/8},
{M2,TT/8},{M1,TT/8},{M1,TT/8},{M5,TT/8},{M5,TT/8},{M3,TT/8},{M2,TT/8},{M3,TT/8},
{M2,TT/8},{M1,TT/8},{M1,TT/8},{M3,TT/8},{M3,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},
{M2,3*TT/16},{M2,TT/16},{M2,TT/8},{M2,TT/8},{M2,3*TT/16},{M1,TT/16},{M1,TT/8},{L6,TT/8},
{M2,3*TT/8},{L5,TT/8},{L6,TT/8},{M1,TT/8},{M2,TT/8},{M1,TT/8},{M2,TT/8},{M3,TT/8},{M3,TT/8},{M5,TT/8},{M5,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},
{M2,TT/8},{M3,TT/8},{M3,TT/8},{M6,TT/8},{M6,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},
{M2,3*TT/16},{M1,TT/16},{M1,TT/16},{M1,TT/8},{L6,TT/8},{M1,3*TT/16},{M2,TT/16},{M2,TT/8},{M3,TT/8},
{M5,3*TT/8},{L5,TT/8},{L6,TT/8},{M1,TT/8},{M2,TT/8},{M1,TT/8},{M2,TT/8},{M1,TT/8},{M1,TT/8},{M6,TT/8},{M6,TT/8},{M5,TT/8},{M3,TT/8},{M3,TT/8},
{M2,TT/8},{M1,TT/8},{M1,TT/8},{M3,TT/8},{M3,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},
{M2,3*TT/16},{M2,TT/16},{M2,TT/8},{M2,TT/8},{M2,3*TT/16},{M1,TT/16},{M1,TT/8},{L6,TT/8},{M1,3*TT/8},{M1,TT/8},{H1,TT/8},{M7,TT/8},{H1,TT/8},{M6,TT/8},
{H1,3*TT/16},{M6,TT/16},{M6,TT/8},{M5,TT/8},{M6,TT/8},{M5,TT/8},{M3,TT/8},{M2,TT/8},
{M3,TT/8},{M5,TT/8},{M6,TT/8},{M5,TT/8},{M5,TT/8},{M5,TT/8},{M6,TT/8},{M5,TT/8},{M6,3*TT/16},{M6,TT/16},{M6,TT/8},{M6,TT/8},{M6,3*TT/16},{M5,TT/16},{M5,TT/8},{M6,TT/8},
{M5,TT/8},{M3,TT/8},{M3,TT/4},{0,TT/8},{M1,TT/8},{M2,TT/8},{M3,TT/8},{M5,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},{M1,TT/8},{M1,TT/8},{M2,TT/8},{M3,TT/8},
{M6,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},{M1,TT/8},{M1,TT/8},{M1,TT/8},{M1,TT/8},
{H1,3*TT/16},{H1,TT/16},{H1,TT/8},{H1,TT/8},{H1,3*TT/16},{M6,TT/16},{M6,TT/8},{H1,TT/8},{M6,3*TT/8},{M5,TT/8},{M5,TT/8},{H1,TT/8},{H1,TT/8},{M7,TT/8},
{H1,TT/8},{M7,TT/8},{M6,TT/8},{M5,TT/8},{M6,TT/8},{M5,TT/8},{M3,TT/8},{M2,TT/8},
{M3,TT/8},{M5,TT/8},{M6,TT/8},{M5,TT/8},{M5,TT/8},{M5,TT/8},{M6,TT/8},{M5,TT/8},
{M6,3*TT/16},{M6,TT/16},{M6,TT/8},{M6,TT/8},{M6,3*TT/16},{M5,TT/16},{M5,TT/8},{M6,TT/8},
{M5,TT/8},{M3,TT/8},{M3,TT/4},{0,TT/8},{M1,TT/8},{M2,TT/8},{M3,TT/8},{M5,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},{M1,TT/8},{M1,TT/8},{M2,TT/8},{M3,TT/8},
{M6,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},{H1,TT/2},{L1,TT/4},{L1,TT/4},{L1,TT/8},{H1,TT/8},{M6,TT/8},{H1,TT/8},
{M6,TT/8},{M5,TT/8},{M5,TT/8},{M5,TT/8},{M6,TT/8},{M5,TT/8},{M3,TT/8},{M2,TT/8},
{M3,TT/8},{M2,TT/8},{M2,TT/8},{M1,TT/8},{L6,TT/8},{M1,TT/8},{M1,TT/8},{M2,TT/8},{M1,TT},{M1,TT},
{M1,TT/2},{M1,TT/8},{H1,TT/8},{M6,TT/8},{H1,TT/8},{H2,TT/8},{H1,TT/8},{H1,TT/8},{H1,TT/8},{H2,TT/8},{H1,TT/8},{M6,TT/8},{H1,TT/8},
{H3,TT/8},{M2,TT/8},{H2,TT/8},{H1,TT/8},{M6,TT/8},{H1,TT/8},{H2,TT/4},{M1,TT},
{0,0},}},
	{"����",64,{{M3,TT/4},{M3,TT/8},{M5,TT/8},{M6,TT/8},{H1,TT/8},{H1,TT/8},{M6,TT/8},{M5,TT/4},{M5,TT/8},{M6,TT/8},{M5,TT/2},
{M3,3*TT/16},{M2,TT/16},{M3,TT/8},{M5,TT/8},{M6,TT/8},{H1,TT/8},{H1,TT/8},{M6,TT/8},{M5,TT/4},{M5,TT/8},{M6,TT/8},{M5,TT/2},
{M5,TT/4},{M5,TT/4},{M5,TT/4},{M3,TT/8},{M5,TT/8},{M6,TT/4},{M6,TT/4},{M5,TT/2},
{M3,TT/4},{M2,TT/8},{M3,TT/8},{M5,TT/4},{M3,TT/8},{M2,TT/8},{M1,TT/4},{M1,TT/8},{M2,TT/8},{M1,TT/2},
{M3,TT/8},{M2,TT/8},{M1,TT/8},{M3,TT/8},{M2,3*TT/8},{M3,TT/8},{M5,TT/4},{M6,TT/8},{H1,TT/8},{M5,TT/2},
{M2,TT/4},{M3,TT/8},{M5,TT/8},{M2,TT/8},{M3,TT/8},{M1,TT/8},{L6,TT/8},{L5,TT/2},{L6,TT/4},{M1,TT/4},
{M2,3*TT/8},{M3,TT/8},{M1,TT/8},{M2,TT/8},{M1,TT/8},{L6,TT/8},{L5,3*TT/4},{0,TT/4},
{0,0},}},
	{"�����",111,{{M3,TT/4},{M3,TT/8},{M3,TT/8},{M4,TT/4},{M5,TT/4},{M3,3*TT/8},{M2,TT/8},{M2,TT/2},
{M1,TT/4},{M1,TT/8},{M1,TT/8},{M2,TT/4},{M3,TT/4},{M3,3*TT/8},{L7,TT/8},{L7,TT/2},
{L6,TT/4},{M3,TT/4},{M2,TT/2},{L6,TT/4},{M3,TT/4},{M2,TT/2},{L6,TT/4},{M3,TT/4},{M2,3*TT/8},{M1,TT/8},{M1,TT},
{0,TT/4},{0,TT/4},{0,TT/4},{0,TT/4},{0,TT/4},{0,TT/4},{0,TT/4},{M3,TT/8},{M2,TT/8},
{M3,TT/4},{M3,TT/8},{M3,TT/8},{M4,TT/4},{M5,TT/4},{M3,3*TT/8},{M2,TT/8},{M2,TT/2},
{M1,TT/4},{M1,TT/8},{M1,TT/8},{M2,TT/4},{M3,TT/4},{M3,3*TT/8},{L7,TT/8},{L7,TT/2},
{L6,TT/4},{M3,TT/4},{M2,TT/2},{L6,TT/4},{M3,TT/4},{M2,TT/2},{L6,TT/4},{M3,TT/4},{M2,3*TT/8},{M1,TT/8},{M1,TT},
{0,TT/4},{0,TT/4},{0,TT/4},{0,TT/4},{0,TT/4},{0,TT/4},{0,TT/4},{M3,TT/8},{M2,TT/8},
{M5,3*TT/4},{M4,TT/8},{M3,TT/8},{M3,TT/8},{M2,TT/8},{M2,TT/2},{M5,TT/8},{M4,TT/8},
{M3,TT/4},{M4,TT/8},{M5,3*TT/8},{M3,TT/4},{M2,3*TT/4},{0,TT/8},{M1,TT/8},
{L6,TT/4},{M3,TT/8},{M2,3*TT/8},{M1,TT/8},{L5,TT/4},{M2,TT/8},{M1,TT/8},{M1,TT/2},
{M4,TT/8},{M3,TT/8},{M4,TT/8},{M3,TT/8},{M1,TT/2},
{M4,TT/8},{M3,TT/8},{M4,TT/8},{M3,TT/8},{M1,3*TT/8},{M2,TT/8},{M1,TT},
{0,TT/4},{0,TT/4},{0,TT/4},{0,TT/4},
{0,0},}},
	{"�ͱ�",126,{{M5,TT/4},{M3,TT/8},{M5,TT/8},{H1,TT/2},{M6,TT/4},{H1,TT/4},{M5,TT/2},{M5,TT/4},{M1,TT/8},{M2,TT/8},{M3,TT/4},{M2,TT/8},{M1,TT/8},{M2,TT/2},{0,TT/4},{0,TT/4},
{M5,TT/4},{M3,TT/8},{M5,TT/8},{H1,3*TT/8},{M7,TT/8},{M6,TT/4},{H1,TT/4},{M5,TT/2},{M5,TT/4},{M2,TT/8},{M3,TT/8},{M4,3*TT/8},{L7,TT/4},{M2,TT/2},{0,TT/4},{0,TT/4},
{M6,TT/4},{H1,TT/4},{H1,TT/2},{M7,TT/4},{M6,TT/8},{M7,TT/8},{H1,TT/2},{M6,TT/8},{M7,TT/8},{H1,TT/8},{M6,TT/8},{M6,TT/8},{M5,TT/8},{M3,TT/8},{M1,TT/8},{M2,TT/2},{0,TT/4},{0,TT/4},
{M5,TT/4},{M3,TT/8},{M5,TT/8},{H1,3*TT/8},{M7,TT/8},{M6,TT/4},{H1,TT/4},{M5,TT/2},{M5,TT/4},{M2,TT/8},{M3,TT/8},{M4,3*TT/8},{L7,TT/4},{M1,TT/2},{0,TT/4},{0,TT/4},
{M5,TT/4},{M3,TT/8},{M5,TT/8},{H1,TT/2},{M6,TT/4},{H1,TT/4},{M5,TT/2},{M5,TT/4},{M1,TT/8},{M2,TT/8},{M3,TT/4},{M2,TT/8},{M1,TT/8},{M2,TT/2},{0,TT/4},{0,TT/4},
{M5,TT/4},{M3,TT/8},{M5,TT/8},{H1,3*TT/8},{M7,TT/8},{M6,TT/4},{H1,TT/4},{M5,TT/2},{M5,TT/4},{M2,TT/8},{M3,TT/8},{M4,3*TT/8},{L7,TT/4},{M2,TT/2},{0,TT/4},{0,TT/4},
{M6,TT/4},{H1,TT/4},{H1,TT/2},{M7,TT/4},{M6,TT/8},{M7,TT/8},{H1,TT/2},{M6,TT/8},{M7,TT/8},{H1,TT/8},{M6,TT/8},{M6,TT/8},{M5,TT/8},{M3,TT/8},{M1,TT/8},{M2,TT/2},{0,TT/4},{0,TT/4},
{M5,TT/4},{M3,TT/8},{M5,TT/8},{H1,3*TT/8},{M7,TT/8},{M6,TT/4},{H1,TT/4},{M5,TT/2},{M5,TT/4},{M2,TT/8},{M3,TT/8},{M4,3*TT/8},{L7,TT/4},{M1,TT/2},{0,TT/4},{0,TT/4},
{0,0},}},
	{"���տ���",50,{{L5,TT/6},{L5,TT/6},{L6,TT/3},{L5,TT/3},{M1,TT/3},{L7,2*TT/3},{L5,TT/6},{L5,TT/6},{L6,TT/3},{L5,TT/3},{M2,TT/3},{M1,2*TT/3},
{L5,TT/6},{L5,TT/6},{M5,TT/3},{M3,TT/3},{M1,TT/3},{L7,TT/3},{L6,TT/3},{M4,TT/4},{M4,TT/12},{M3,TT/3},{M1,TT/3},{M2,TT/3},{M1,2*TT/3},
{L5,TT/6},{L5,TT/6},{L6,TT/3},{L5,TT/3},{M1,TT/3},{L7,2*TT/3},{L5,TT/6},{L5,TT/6},{L6,TT/3},{L5,TT/3},{M2,TT/3},{M1,2*TT/3},
{L5,TT/6},{L5,TT/6},{M5,TT/3},{M3,TT/3},{M1,TT/3},{L7,TT/3},{L6,TT/3},{M4,TT/4},{M4,TT/12},{M3,TT/3},{M1,TT/3},{M2,TT/3},{M1,2*TT/3},
{0,0},}},
	{"���������",209,{{L6,TT/4},{L6,TT/8},{L5,TT/8},{L6,TT/4},{L6,TT/8},{L6,TT/8},{M1,TT/4},{M2,TT/8},{M1,TT/8},{L6,TT/2},{M1,TT/4},{M1,TT/8},{L5,TT/8},{M1,TT/8},{M2,TT/8},{M3,TT/8},{M5,TT/8},
{M5,TT/8},{M3,TT/8},{M2,TT/4},{M3,TT/2},{M6,3*TT/16},{M6,TT/16},{M6,TT/8},{M5,TT/8},{M3,TT/8},{M3,TT/4},{M1,TT/8},{L6,TT/8},{L6,TT/8},{L6,TT/8},{M3,TT/8},
{M2,TT/2},{M3,TT/8},{M3,TT/8},{M5,TT/8},{M3,TT/8},{M2,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},{L6,TT/4},{L5,TT/4},{L6,TT/2}, 
{L6,TT/4},{L6,TT/8},{L5,TT/8},{L6,TT/4},{L6,TT/8},{L6,TT/8},{M1,TT/4},{M2,TT/8},{M1,TT/8},{L6,TT/2},{M1,TT/4},{M1,TT/8},{L5,TT/8},{M1,TT/8},{M2,TT/8},{M3,TT/8},{M5,TT/8},
{M5,TT/8},{M3,TT/8},{M2,TT/4},{M3,TT/2},{M6,3*TT/16},{M6,TT/16},{M6,TT/8},{M5,TT/8},{M3,TT/8},{M3,TT/4},{M1,TT/8},{L6,TT/8},{L6,TT/8},{L6,TT/8},{M3,TT/8},
{M2,TT/2},{M3,TT/8},{M3,TT/8},{M5,TT/8},{M3,TT/8},{M2,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},{L6,TT/4},{L5,TT/4},{L6,TT/2}, 
{M3,3*TT/16},{M3,TT/16},{M5,TT/8},{M3,TT/8},{M3,3*TT/16},{M5,TT/16},{M5,TT/8},{M6,TT/8},{M6,TT/4},{M5,TT/4},{M6,TT/2},
{L6,TT/4},{L6,TT/8},{L5,TT/8},{L6,TT/4},{M1,TT/4},{M2,TT/8},{M3,TT/8},{M1,TT/8},{M2,TT/8},{M3,TT/2},{M3,TT/8},{M6,TT/8},{M6,TT/8},{M5,TT/8},{M3,TT/8},{M2,TT/8},
{M1,TT/8},{M2,TT/8},{M3,TT},{M1,TT/8},{L6,TT/8},{L6,TT/8},{M2,TT/4},{M6,3*TT/16},{M6,TT/16},{M3,TT/8},{M5,TT/8},{M3,TT/8},{M2,TT/8},{M1,3*TT/8},{L6,TT/8},{L6,TT/8},{M1,TT/8},{M2,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},
{L6,TT/8},{L5,TT/8},{L6,TT},
{L6,TT/4},{L6,TT/8},{L5,TT/8},{L6,TT/4},{M1,TT/4},{M2,TT/8},{M3,TT/8},{M1,TT/8},{M2,TT/8},{M3,TT/2},{M3,TT/8},{M6,TT/8},{M6,TT/8},{M5,TT/8},{M3,TT/8},{M2,TT/8},
{M1,TT/8},{M2,TT/8},{M3,TT},{M1,TT/8},{L6,TT/8},{L6,TT/8},{M2,TT/4},{M6,3*TT/16},{M6,TT/16},{M3,TT/8},{M5,TT/8},{M3,TT/8},{M2,TT/8},{M1,3*TT/8},{L6,TT/8},{L6,TT/8},{M1,TT/8},{M2,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},
{L6,TT/8},{L5,TT/8},{L6,TT},
{L6,TT/8},{M1,TT/8},{M2,TT/8},{M3,TT/8},{M5,TT/8},{M5,TT/8},{M6,TT/8},{M6,TT},
{M6,3*TT/16},{M6,TT/16},{M6,TT/8},{M6,TT/8},{M6,3*TT/16},{M5,TT/16},{M3,TT/4},{M2,3*TT/16},{M3,TT/16},
{M5,TT/8},{M3,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/2},{L6,TT/8},
{L6,TT/4},{L6,TT/8},{L5,TT/8},{L6,TT/4},{L6,TT/8},{M1,TT/8},{M2,TT/8},{M3,TT/8},{M1,TT/8},{M2,TT/8},{M3,TT/2},
{M6,TT/8},{M5,TT/8},{M3,TT/8},{M2,TT/8},
{M1,TT/8},{M1,TT}, 
{0,0},}},
	{"������",61,{{0,TT/2},{H5,TT/4},{H6,TT/4},{H1,3*TT/8},{H7,TT/8},{H6,TT/4},{H5,TT/4},{H1,TT/8},{H1,TT/4},{H7,TT/8},{H6,TT/4},{H5,TT/4},
{H3,3*TT/16},{H3,TT/16},{H3,TT/8},{H3,TT/8},{H1,TT/8},{H7,TT/8},{H6,TT/4},{H5,3*TT/4},{H3,TT/4},{H2,TT/4},{0,TT/8},{H3,TT/8},
{H5,TT/4},{M7,TT/4},{M6,TT/8},{M7,TT/16},{M6,TT/16},{M5,TT/8},{M6,TT/8},{H1,TT/4},{H1,TT/4},{M6,TT/8},{M7,TT/16},{M6,TT/16},
{M5,TT/8},{M6,TT/8},{H2,TT/8},{M7,TT/8},{M6,TT/8},{H1,TT/8},{M5,TT},{H5,TT/4},{H2,TT/8},{H3,TT/8},{H1,3*TT/16},{M7,TT/16},
{M6,TT/8},{M5,TT/8},{H1,3*TT/4},{M6,TT/4},{H6,3*TT/16},{H6,TT/16},{H6,TT/8},{H1,TT/8},{H6,TT/8},{H5,TT/8},{H5,TT/8},{H3,TT/8},
{H2,TT},
{0,0},}},
	{"С����",84,{{M1,TT/4},{M1,TT/4},{M5,TT/4},{M5,TT/4},{M6,TT/4},{M6,TT/4},{M5,TT/2},{M4,TT/4},{M4,TT/4},{M3,TT/4},{M3,TT/4},
{M2,TT/4},{M2,TT/4},{M1,TT/2},{M5,TT/4},{M5,TT/4},{M4,TT/4},{M4,TT/4},{M3,TT/4},{M3,TT/4},{M2,TT/2},
{M5,TT/4},{M5,TT/4},{M4,TT/4},{M4,TT/4},{M3,TT/4},{M3,TT/4},{M2,TT/2},{M1,TT/4},{M1,TT/4},{M5,TT/4},{M5,TT/4},
{M6,TT/4},{M6,TT/4},{M5,TT/2},{M4,TT/4},{M4,TT/4},{M3,TT/4},{M3,TT/4},{M2,TT/4},{M2,TT/4},{M1,TT/2},
{M1,TT/4},{M1,TT/4},{M5,TT/4},{M5,TT/4},{M6,TT/4},{M6,TT/4},{M5,TT/2},{M4,TT/4},{M4,TT/4},{M3,TT/4},{M3,TT/4},
{M2,TT/4},{M2,TT/4},{M1,TT/2},{M5,TT/4},{M5,TT/4},{M4,TT/4},{M4,TT/4},{M3,TT/4},{M3,TT/4},{M2,TT/2},
{M5,TT/4},{M5,TT/4},{M4,TT/4},{M4,TT/4},{M3,TT/4},{M3,TT/4},{M2,TT/2},{M1,TT/4},{M1,TT/4},{M5,TT/4},{M5,TT/4},
{M6,TT/4},{M6,TT/4},{M5,TT/2},{M4,TT/4},{M4,TT/4},{M3,TT/4},{M3,TT/4},{M2,TT/4},{M2,TT/4},{M1,TT/2},
{0,0},}},
	};

//PWM��ʼ��

void BEEP_PWM_Init(u16 arr,u16 psc)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;


	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_BEEP_CLK | RCC_APB2Periph_AFIO, ENABLE);

	//GPIO_PinRemapConfig(GPIO_PartialRemap_TIM3, ENABLE); //TIM3������ӳ��TIM3_CH4->PB0

	GPIO_InitStructure.GPIO_Pin = BEEP_Pin; //TIM3_CH4
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;//�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(BEEP_GPIO, &GPIO_InitStructure);

	TIM_TimeBaseStructure.TIM_Period = arr;
	TIM_TimeBaseStructure.TIM_Prescaler =psc;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseStructure);

	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2; 
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; 
	TIM_OCInitStructure.TIM_Pulse = 0; 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;//TIM_OCPolarity_High;//TIM_OCPolarity_Low; 
	TIM_OC4Init(TIM3, &TIM_OCInitStructure);
	TIM_OC4PreloadConfig(TIM3, TIM_OCPreload_Enable);

	TIM_CCxCmd(TIM3,TIM_Channel_4 ,ENABLE);
	TIM_ARRPreloadConfig(TIM3, ENABLE); 
	TIM_Cmd(TIM3, ENABLE);
} 
//������ֹͣ����
void buzzerQuiet(void)
{
	TIM_SetCompare4(TIM3,0);
	TIM_CCxCmd(TIM3,TIM_Channel_4 ,DISABLE);

}

void buzzerSound(unsigned short usFreq)
{
	unsigned long ulVal;
	if((usFreq<=8000000/65536UL)||(usFreq>20000))
	{ 
		buzzerQuiet();
	}
	else
	{
		ulVal=8000000/usFreq;//
		TIM3->ARR =ulVal;//��ʱ����װ�ؼĴ������ڵ�ֵ
		TIM_SetCompare4(TIM3,ulVal /2);//�����ߵ�
		TIM_CCxCmd(TIM3,TIM_Channel_4 ,ENABLE);//����ʱ��
	}
}

//��������
void musicPlay()
{
	u8 len=0;
	u8 key=0;  //��¼��ֵ 
	u8 j=0;
	u8 rate=0;//��¼���Ž��� 
	temp = id;

	len = Mysong[temp].Len/15; //һ�����15��I 
	while(1){
		//printf("%d,%d",id,temp);
		key=KEY_Scan(0); //S2=��ͣ/������S4=��һ�ס�S6=�����S8=���� 
		if(key==2&&pause)//��ʼ���š���ͣ��������� 
			pause=0; 
		else if(key==2&&!pause)//��ͣ 
			pause=1;
		if(pause)
			continue;
		if(key==4)
			while(KEY_Scan(0)!=2)
			{
				OLED_Clear();
				OLED_ShowSong(0,0,(id+1)%10); //��ʾ����
				OLED_ShowSong(0,16,(id+2)%10); //��ʾ����
				OLED_ShowSong(0,32,(id+3)%10); //��ʾ����
				OLED_ShowSong(0,48,(id+4)%10); //��ʾ����
				OLED_Refresh();
				delay_ms(100);
			} 
		if(Mysong[temp].lyrics[j].mTime!= 0)
		{
			buzzerSound(Mysong[temp].lyrics[j].mName);
			if(Mysong[temp].lyrics[j].mTime!=0)
			    delay_ms(Mysong[temp].lyrics[j].mTime);
			j++;
			if(key==6)//��� 
				j+=15;
			else if(key==8)//���� 
			{
				if(j-15<0)
					j=0;
				else
					j-=15;
			} 
			rate=j/len; //��ʾ����I��ʾ����
			OLED_Clear();
			OLED_ShowSong(0,0,id); //��ʾ���� 
			OLED_ShowRate(0,16,rate,16); //��ʾ���� 
			if(j<=15)
				OLED_ShowSpectrum(id,0,j);
			else
				OLED_ShowSpectrum(id,j-15,j);
			OLED_Refresh();
			buzzerQuiet(); // ��ֹ���м䷢���������Լ��������ֵ�ͣ�� 
			delay_ms(10);
		}
		else
			id=(id+1)%10;
		if(key==10)  //��һ�� 
			id=(id+1)%10; 
		else if(key==12)//��һ�� 
		{
			if(id==0)
				id=9;
			else
				id--;
		}
		if(id != temp)	return;//�и� 
		}
}

void musicshow()
{
	u8 j = 0;
	while(j<10)
	{
		printf("%d:%s\r\n",j,Mysong[j].songName);
		j++;
	}
}

